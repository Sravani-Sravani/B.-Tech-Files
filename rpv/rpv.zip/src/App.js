import PatientView from './Components/PatientView';
function App() {
  return (
    <>
      <PatientView></PatientView>
    </>
  );
}

export default App;
