import * as React from 'react';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Grid';
import Autocomplete from '@mui/material/Autocomplete';
import Stack from '@mui/material/Stack';
import Link from '@mui/material/Link';
import './patientview_style.css';
import { Box } from '@mui/system';
//import { ThemeProvider } from "@material-ui/styles";

const options = [
  { label: 'One', id: 1 },
  { label: 'Two', id: 2 },
];
const PatientView = () => {
   
  const [crfd, setCrfd] = React.useState(null);
  const [crtd, setCrtd] = React.useState(null);
  const [ap, setAp] = React.useState('');
  const [po, setPo] = React.useState('');
  const [dept, setDept] = React.useState('');
  const [wfcat, setWfcat] = React.useState('');
  const [section, setSection] = React.useState('');
  const [crid, setCrid] = React.useState('');
  const [astate, setAstate] = React.useState('');
  const resetForm = () => {
    setCrfd(null)
    setCrtd(null)
    setAp('')
    setPo("")
    setDept("")
    setWfcat("")
    setSection("")
    setCrid("")
    setAstate("")
  }
  return (
    <>
    <Typography sx={{fontFamily:'Lato, sans-serif'}} px={3} color="#808080" gutterBottom>
            REGISTERED PATIENTS VIEW
          </Typography>
      <Card sx={{ mt: 2, ml: 2 }} spacing={4}>
        <CardContent>
        
          <Grid
            container
            direction="row" 
            rowSpacing={1}
            columnSpacing={2}
            justify="flex-end"
            alignItems="center"
          >
<Grid item xs={12} sm={4} md={4} lg={4}>
              <TextField
                margin="normal"
                required
                fullWidth
                id="crid"
                label="Patient Number"
                value={crid}
                onChange={(newValue) => setCrid(newValue.target.value)}
                autoComplete="email"
                size="small"
              />
            </Grid>
            <Grid item xs={12} sm={4} md={4} lg={4}>
              <TextField
                margin="normal"
                required
                fullWidth
                id="crid"
                label="Patient Name"
                value={crid}
                onChange={(newValue) => setCrid(newValue.target.value)}
                autoComplete="email"
                size="small"
              />
            </Grid>
            <Grid item xs={12} sm={4} md={4} lg={4}>
              <TextField
                margin="normal"
                required
                fullWidth
                id="crid"
                label="Health Card No"
                value={crid}
                onChange={(newValue) => setCrid(newValue.target.value)}
                autoComplete="email"
                size="small"
              />
            </Grid>
            <Grid item xs={12} sm={6} md={6} lg={6}>
              <Autocomplete
                disablePortal
                value={astate}
                onChange={(event, value) => { setAstate(value) }}
                margin="normal"
                fullWidth
                size="small"
                id="combo-box-demo"
                options={options}
                sx={{ width: "100%", mt: 1 }}
                renderInput={(params) => (
                  <TextField {...params} label="State" />
                )}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={6} lg={6}>
              <Autocomplete
                disablePortal
                value={astate}
                onChange={(event, value) => { setAstate(value) }}
                margin="normal"
                fullWidth
                size="small"
                id="combo-box-demo"
                options={options}
                sx={{ width: "100%", mt: 1 }}
                renderInput={(params) => (
                  <TextField {...params} label="District" />
                )}
              />
            </Grid>
            
            <Grid item xs={12} sm={6} md={6} lg={6} >
              <LocalizationProvider dateAdapter={AdapterDayjs}>
                <Box sx={{height:'10px'}}>
                <DatePicker
                  label="CR raised From Date"
                  inputFormat="MM/DD/YYYY"
                  // sx={{height:'50%',width:'100%',mt:1}}
                  value={crfd}
                  onChange={(newValue) => {
                    setCrfd(newValue);
                  }}
                  renderInput={(params) => (
                    <TextField  name="td" 
                    
                    sx={{'.MuiInputBase-input':{height:10},           
                  
                  }} 
                  fullWidth {...params} />
                  )}
                /></Box>
              </LocalizationProvider>
            </Grid>
            <Grid item xs={12} sm={6} md={6} lg={6}>
              <LocalizationProvider dateAdapter={AdapterDayjs}>
                <DatePicker
                  label=" CR raised To Date"
                  inputFormat="MM/DD/YYYY"
                  value={crtd}
                  sx={{width:'100%',mt:1}}
                  onChange={(newValue) => {
                    setCrtd(newValue);
                  }} 
                  renderInput={(params) => (
                    <TextField
                      size="small"
                      sx={{height:100}}
                      fullWidth 
                      {...params}
                    />
                  )}
                />
              </LocalizationProvider>
            </Grid>
           
              

          </Grid>
          <br></br>
          <Stack direction="row"
            justifyContent="center"
            alignItems="center"
            spacing={1}>
            <Button sx={{ minWidth: 100, ml: 1, backgroundColor: '#3F51B5', ":hover": { backgroundColor: '#3F51B5', color: 'white', fontWeight: 'bold' } }} variant="contained">
              <Link href="/#/page2" sx={{ textDecorationColor: 'none', color: 'white', fontWeight: 'bold' }}> Generate Report</Link>
            </Button>
            <Button onClick={() => resetForm()} sx={{ minWidth: 100, ml: 1, color: '#3F51B5', border: '1px solid #3F51B5', fontWeight: 'bold' }} variant="outlined">
              Reset
            </Button>
          </Stack>
        </CardContent>



      </Card>
    </>
  )
}

export default PatientView
